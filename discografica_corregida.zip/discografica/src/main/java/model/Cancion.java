package main.java.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity(name = "cancion")
public class Cancion {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	// El título puede repetirse (no es unique)
	@Column(nullable = false)
	private String titulo;

	// Descripción obligatoria según el enunciado
	@Column(nullable = false)
	private String descripcion;

	// Duración en segundos
	@Column(nullable = false)
	private long duracion;

	// Formato de audio: mp3, wav, flac, etc.
	@Column(nullable = false)
	private String formato;

	// Cada canción pertenece a un único álbum (nullable para el CRUD independiente)
	@ManyToOne(fetch = FetchType.LAZY, optional = true)
	@JoinColumn(name = "album_id", nullable = true)
	private Album album;

	public Cancion() {
		super();
	}

	// Constructor SIN álbum (para el CRUD independiente del punto a)
	public Cancion(String titulo, String descripcion, long duracion, String formato) {
		super();
		this.titulo = titulo;
		this.descripcion = descripcion;
		this.duracion = duracion;
		this.formato = formato;
	}

	// Constructor CON álbum (para usarlo desde el CRUD de Album)
	public Cancion(String titulo, String descripcion, long duracion, String formato, Album album) {
		this(titulo, descripcion, duracion, formato);
		this.album = album;
	}

	// Getters y Setters
	public long getId() { return id; }
	public void setId(long id) { this.id = id; }

	public String getTitulo() { return titulo; }
	public void setTitulo(String titulo) { this.titulo = titulo; }

	public String getDescripcion() { return descripcion; }
	public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

	public long getDuracion() { return duracion; }
	public void setDuracion(long duracion) { this.duracion = duracion; }

	public String getFormato() { return formato; }
	public void setFormato(String formato) { this.formato = formato; }

	public Album getAlbum() { return album; }
	public void setAlbum(Album album) { this.album = album; }

	@Override
	public String toString() {
		return "Cancion{id=" + id + ", titulo='" + titulo + "', duracion=" + duracion
				+ "s, formato=" + formato
				+ (album != null ? ", album='" + album.getNombre() + "'" : "") + "}";
	}
}
