package main.java.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;

@Entity(name = "album")
public class Album {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	// El nombre puede repetirse (puede haber varios "Grandes Éxitos")
	@Column(nullable = false)
	private String nombre;

	@Column(nullable = false)
	private int anio;

	// Cada álbum pertenece exclusivamente a un solo grupo
	@ManyToOne(optional = false)
	@JoinColumn(name = "grupo_id", nullable = false)
	private Grupo grupo;

	// Un álbum tiene una o más canciones
	// cascade=MERGE: cuando actualizamos el álbum, actualizamos también sus canciones
	@OneToMany(mappedBy = "album", cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
	private List<Cancion> canciones = new ArrayList<>();

	public Album() {
		super();
	}

	public Album(String nombre, int anio, Grupo grupo) {
		super();
		this.nombre = nombre;
		this.anio = anio;
		this.grupo = grupo;
	}

	// Método helper: añade una canción y establece la relación bidireccional
	public void agregarCancion(Cancion cancion) {
		canciones.add(cancion);
		cancion.setAlbum(this);
	}

	// Getters y Setters
	public long getId() { return id; }
	public void setId(long id) { this.id = id; }

	public String getNombre() { return nombre; }
	public void setNombre(String nombre) { this.nombre = nombre; }

	public int getAnio() { return anio; }
	public void setAnio(int anio) { this.anio = anio; }

	public Grupo getGrupo() { return grupo; }
	public void setGrupo(Grupo grupo) { this.grupo = grupo; }

	public List<Cancion> getCanciones() { return canciones; }
	public void setCanciones(List<Cancion> canciones) { this.canciones = canciones; }

	@Override
	public String toString() {
		return "Album{id=" + id + ", nombre='" + nombre + "', anio=" + anio
				+ ", grupo='" + grupo.getNombre() + "', canciones=" + canciones.size() + "}";
	}
}
