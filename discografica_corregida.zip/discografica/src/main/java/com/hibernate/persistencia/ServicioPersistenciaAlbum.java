package main.java.com.hibernate.persistencia;

import java.util.List;

import org.hibernate.Session;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Album;

/**
 * CRUD completo de la entidad Album, asociada a Grupo y Cancion.
 * Cada método captura sus propios errores e informa sin detener la ejecución.
 */
public class ServicioPersistenciaAlbum {

	// CREATE
	// El álbum debe tener un Grupo ya persistido y al menos una Canción
	// ya persistida. Aquí establecemos la relación.
	public void persistir(Album album) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			session.persist(album);
			session.getTransaction().commit();
			session.close();
			System.out.println("Album guardado: " + album);
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo guardar el album '" + album.getNombre() + "': " + e.getMessage());
		}
	}

	// READ por id
	public Album obtener(long id) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			Album album = session.find(Album.class, id);
			session.close();
			if (album == null) {
				System.out.println("[ERROR] No existe ningún album con id=" + id);
			}
			return album;
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo obtener el album con id=" + id + ": " + e.getMessage());
			return null;
		}
	}

	// READ todos
	public List<Album> obtenerTodos() {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			List<Album> albumes = session.createQuery("from album", Album.class).list();
			session.close();
			return albumes;
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudieron obtener los albums: " + e.getMessage());
			return List.of();
		}
	}

	// UPDATE
	public void actualizar(Album album) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			session.merge(album);
			session.getTransaction().commit();
			session.close();
			System.out.println("Album actualizado: " + album);
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo actualizar el album: " + e.getMessage());
		}
	}

	// DELETE
	public void eliminar(long id) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			Album album = session.find(Album.class, id);
			if (album == null) {
				System.out.println("[ERROR] No existe ningún album con id=" + id + " para eliminar");
				session.close();
				return;
			}
			// Desvinculamos las canciones antes de borrar el álbum
			for (var cancion : album.getCanciones()) {
				cancion.setAlbum(null);
				session.merge(cancion);
			}
			session.remove(album);
			session.getTransaction().commit();
			session.close();
			System.out.println("Album eliminado con id=" + id);
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo eliminar el album con id=" + id + ": " + e.getMessage());
		}
	}
}
