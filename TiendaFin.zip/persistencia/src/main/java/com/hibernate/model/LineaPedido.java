package com.hibernate.model;

import java.time.LocalDate;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.ForeignKey;

@Entity
@Table(name = "linea_pedido")

public class LineaPedido {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @ManyToOne(optional = false)
    @JoinColumn(name = "id_pedido",
            foreignKey = @ForeignKey(name = "pedido_id_fk"),
            nullable = false, updatable = false)
    private Pedido pedido;

    @ManyToOne
    private Producto producto;

    @Column(name = "cantidad")
    private int cantidad;

    @Column(name = "fecha_creacion")
    private LocalDate fechaCreacion;

    @Column(name = "codigo")
    private String codigo;

    public LineaPedido() { super(); }

    public LineaPedido(Producto producto, int cantidad, String codigo, Pedido pedido) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.codigo = codigo;
        this.pedido = pedido;
        this.fechaCreacion = LocalDate.now();
    }

    public long getId() {
    	return id; }
    
    public Pedido getPedido() {
    	return pedido; }
    
    public void setPedido(Pedido pedido) {
    	this.pedido = pedido; }
    
    public Producto getProducto() {
    	return producto; }
    
    public void setProducto(Producto producto) {
    	this.producto = producto; }
    
    public int getCantidad() {
    	return cantidad; }

    public void setCantidad(int cantidad) {
    	this.cantidad = cantidad; }
    
    public String getCodigo() {
    	return codigo; }
    
    public void setCodigo(String codigo) {
    	this.codigo = codigo; }
    
    public LocalDate getFechaCreacion() {
    	return fechaCreacion; }
    
    public void setFechaCreacion(LocalDate fechaCreacion) {
    	this.fechaCreacion = fechaCreacion; }
}