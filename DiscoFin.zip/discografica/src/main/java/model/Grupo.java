package main.java.model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Transient;

@Entity(name = "grupo")
public class Grupo {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long id;
	
	@Column(nullable = false, unique = true)
	private String nombre;
	
	@Column(name = "fecha_creacion", nullable = false)
	private LocalDate fechaCreacion;
	
	@Column(name = "fecha_disolucion", nullable = true)
	private LocalDate fechaDisolucion;
	
	
	
	@OneToMany(mappedBy ="grupo", cascade = CascadeType.ALL)
	private List<Album> ListAlbum=new ArrayList<>();
	
	
	public Grupo() {
		super();
	}

	public Grupo(String nombre, LocalDate fechaCreacion, LocalDate fechaDisolucion) {
		super();
		this.nombre=nombre;
		this.fechaCreacion=fechaCreacion;
		this.fechaDisolucion=fechaDisolucion;
	}



	public void addAlbum(Album album) {
		this.ListAlbum.add(album);
		album.setGrupo(this);
	}
	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public LocalDate getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(LocalDate fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public LocalDate getFechaDisolucion() {
		return fechaDisolucion;
	}

	public void setFechaDisolucion(LocalDate fechaDisolucion) {
		this.fechaDisolucion = fechaDisolucion;
	}
	
	@Override
	public String toString() {
		return this.nombre +" se creó en " + fechaCreacion.getYear() + 
							((this.fechaDisolucion!=null)?" y se disolvió en "+fechaDisolucion.getYear():"");
	}
	
	
}
