package com.hibernate;

import org.hibernate.Session;

public class ServicioPersistencia<T> {

	  public void persistirObjeto(T objeto) {
	        Session session = ConnectionUtil.getSessionFactory().openSession();
	        session.beginTransaction();
	        session.persist(objeto);
	        session.getTransaction().commit();
	        session.close();
	    }

	    public T obtenerPorId(Class<T> clase, long id) {
	        Session session = ConnectionUtil.getSessionFactory().openSession();
	        session.beginTransaction();
	        T objeto = session.find(clase, id);
	        session.close();
	        return objeto;
	    }
	}
