package main.java.com.hibernate.persistencia;

import java.util.List;

import org.hibernate.Session;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Cancion;

/**
 * CRUD completo de la entidad Cancion, sin asociar a ninguna otra entidad.
 * Cada método captura sus propios errores e informa sin detener la ejecución.
 */
public class ServicioPersistenciaCancion {

	// CREATE
	public void persistir(Cancion cancion) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			session.persist(cancion);
			session.getTransaction().commit();
			session.close();
			System.out.println("Cancion guardada: " + cancion);
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo guardar la cancion '" + cancion.getTitulo() + "': " + e.getMessage());
		}
	}

	// READ por id
	public Cancion obtener(long id) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			Cancion cancion = session.find(Cancion.class, id);
			session.close();
			if (cancion == null) {
				System.out.println("[ERROR] No existe ninguna cancion con id=" + id);
			}
			return cancion;
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo obtener la cancion con id=" + id + ": " + e.getMessage());
			return null;
		}
	}

	// READ todas
	public List<Cancion> obtenerTodas() {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			List<Cancion> canciones = session.createQuery("from cancion", Cancion.class).list();
			session.close();
			return canciones;
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudieron obtener las canciones: " + e.getMessage());
			return List.of();
		}
	}

	// UPDATE
	public void actualizar(Cancion cancion) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			session.merge(cancion);
			session.getTransaction().commit();
			session.close();
			System.out.println("Cancion actualizada: " + cancion);
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo actualizar la cancion: " + e.getMessage());
		}
	}

	// DELETE
	public void eliminar(long id) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			Cancion cancion = session.find(Cancion.class, id);
			if (cancion == null) {
				System.out.println("[ERROR] No existe ninguna cancion con id=" + id + " para eliminar");
				session.close();
				return;
			}
			session.remove(cancion);
			session.getTransaction().commit();
			session.close();
			System.out.println("Cancion eliminada con id=" + id);
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo eliminar la cancion con id=" + id + ": " + e.getMessage());
		}
	}
}
