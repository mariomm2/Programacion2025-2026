package main.java.com.hibernate.persistencia;

import org.hibernate.Session;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Cancion;
import main.java.model.Grupo;

public class ServicioPersistenciaCancion {

	//Ejemplo con excepcion
	
	/*public void persistir(Cancion cancion) {
	    Session session = ConnectionUtil.getSessionFactory().openSession();
	    try {
	        session.beginTransaction();
	        session.persist(cancion);
	        session.getTransaction().commit();
	        System.out.println("Se ha persistido una cancion.");
	    } catch (Exception e) {
	        if (session.getTransaction() != null) {
	            session.getTransaction().rollback();
	        }
	        // Informa del error SIN lanzar la excepción → el programa continúa
	        System.err.println("Error al persistir canción [" 
	            + e.getClass().getSimpleName() + "]: " + e.getMessage());
	    } finally {
	        session.close();
	    }
	}*/
	
	public void persistir(Cancion cancion) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.persist(cancion);
		session.getTransaction().commit();
		session.close();
		
		System.out.println("Se ha persistido una cancion.");
	}
	
	public Cancion obtener(long id) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Cancion cancion = session.find(Cancion.class, id);
		session.close();
		return cancion;
		
		
	}
	
	public void actualizar(Cancion cancion) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.merge(cancion);
		session.getTransaction().commit();
		session.close();
		
		System.out.println("Se ha actualizado la cnacion con nombre: "+cancion.getNombre());
	}
	
	public void eliminar(long idCancion) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.remove(session.find(Cancion.class, idCancion));
		session.getTransaction().commit();
		session.close();
		
		System.out.println("Cancion eliminada");
	}

	
}
