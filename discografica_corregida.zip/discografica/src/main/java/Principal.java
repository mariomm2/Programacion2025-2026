package main.java;

import java.time.LocalDate;

import main.java.com.hibernate.ConnectionUtil;
import main.java.com.hibernate.persistencia.ServicioPersistenciaAlbum;
import main.java.com.hibernate.persistencia.ServicioPersistenciaCancion;
import main.java.com.hibernate.persistencia.ServicioPersistenciaGrupo;
import main.java.model.Album;
import main.java.model.Cancion;
import main.java.model.Grupo;

public class Principal {

	public static void main(String[] args) {

		ServicioPersistenciaGrupo servicioGrupo       = new ServicioPersistenciaGrupo();
		ServicioPersistenciaCancion servicioCancion    = new ServicioPersistenciaCancion();
		ServicioPersistenciaAlbum servicioAlbum        = new ServicioPersistenciaAlbum();

		// ==================================================================
		// PARTE A: CRUD completo de Cancion SIN asociar a ninguna otra entidad
		// (mínimo 5 ejemplos)
		// ==================================================================
		System.out.println("\n========== CRUD CANCION (sin asociar a Album) ==========");

		// 1. CREATE - guardar 5 canciones independientes
		Cancion c1 = new Cancion("Chop Suey!", "Intro épica con guitarra", 210, "mp3");
		Cancion c2 = new Cancion("B.Y.O.B.", "Canción de crítica antibelicista", 254, "mp3");
		Cancion c3 = new Cancion("Toxicity", "Riff icónico de los 2000", 223, "wav");
		Cancion c4 = new Cancion("Aerials", "Balada progresiva", 258, "flac");
		Cancion c5 = new Cancion("Lonely Day", "La más popular de la banda", 176, "mp3");

		servicioCancion.persistir(c1);
		servicioCancion.persistir(c2);
		servicioCancion.persistir(c3);
		servicioCancion.persistir(c4);
		servicioCancion.persistir(c5);

		// 2. READ - obtener una canción por id
		System.out.println("\n-- Obtener cancion id=1 --");
		Cancion leida = servicioCancion.obtener(1L);
		System.out.println("Leída: " + leida);

		// 3. READ - obtener todas
		System.out.println("\n-- Todas las canciones --");
		servicioCancion.obtenerTodas().forEach(System.out::println);

		// 4. UPDATE - modificar una canción
		System.out.println("\n-- Actualizar cancion id=1 --");
		if (leida != null) {
			leida.setFormato("flac");
			leida.setDuracion(215);
			servicioCancion.actualizar(leida);
		}

		// 5. DELETE - eliminar una canción
		System.out.println("\n-- Eliminar cancion id=5 --");
		servicioCancion.eliminar(5L);
		System.out.println("Canciones tras el borrado:");
		servicioCancion.obtenerTodas().forEach(System.out::println);

		// PRUEBA DE ERRORES: operación inválida (no debe detener el programa)
		System.out.println("\n-- Intentar obtener una cancion inexistente (id=999) --");
		servicioCancion.obtener(999L);
		System.out.println("El programa continúa correctamente.");

		// ==================================================================
		// PARTE C: CRUD completo de Album asociado a Grupo y Cancion
		// ==================================================================
		System.out.println("\n========== CRUD ALBUM (asociado a Grupo y Cancion) ==========");

		// 1. Necesitamos un Grupo persistido previamente
		Grupo grupo = new Grupo("System of a Down", LocalDate.of(1994, 11, 10), null);
		servicioGrupo.persistir(grupo);

		// Intentar insertar el mismo grupo (nombre unique -> debe capturar el error)
		System.out.println("\n-- Intentar duplicar el grupo (debe mostrar error) --");
		servicioGrupo.persistir(new Grupo("System of a Down", LocalDate.of(1994, 11, 10), null));
		System.out.println("El programa continúa tras el error.");

		// 2. Obtenemos canciones ya persistidas para asociarlas al álbum
		Cancion cancionAlbum1 = servicioCancion.obtener(1L); // Chop Suey!
		Cancion cancionAlbum2 = servicioCancion.obtener(2L); // B.Y.O.B.
		Cancion cancionAlbum3 = servicioCancion.obtener(3L); // Toxicity

		// 3. CREATE Album
		System.out.println("\n-- Crear album con canciones --");
		Album album = new Album("Toxicity", 2001, grupo);
		if (cancionAlbum1 != null) album.agregarCancion(cancionAlbum1);
		if (cancionAlbum2 != null) album.agregarCancion(cancionAlbum2);
		if (cancionAlbum3 != null) album.agregarCancion(cancionAlbum3);
		servicioAlbum.persistir(album);

		// 4. READ Album por id
		System.out.println("\n-- Obtener album id=1 --");
		Album albumLeido = servicioAlbum.obtener(1L);
		System.out.println("Leído: " + albumLeido);
		if (albumLeido != null) {
			System.out.println("  Canciones del álbum:");
			albumLeido.getCanciones().forEach(c -> System.out.println("    - " + c));
		}

		// 5. READ todos los álbumes
		System.out.println("\n-- Todos los albums --");
		servicioAlbum.obtenerTodos().forEach(System.out::println);

		// 6. UPDATE Album
		System.out.println("\n-- Actualizar album id=1 --");
		if (albumLeido != null) {
			albumLeido.setNombre("Toxicity (Edición especial)");
			albumLeido.setAnio(2002);
			servicioAlbum.actualizar(albumLeido);
		}

		// 7. Crear un segundo álbum del mismo grupo
		System.out.println("\n-- Crear segundo album del mismo grupo --");
		Cancion cancionAlbum4 = servicioCancion.obtener(4L); // Aerials
		Album album2 = new Album("Steal This Album!", 2002, grupo);
		if (cancionAlbum4 != null) album2.agregarCancion(cancionAlbum4);
		servicioAlbum.persistir(album2);

		// 8. DELETE Album
		System.out.println("\n-- Eliminar album id=2 --");
		servicioAlbum.eliminar(2L);

		// PRUEBA DE ERRORES: album inexistente
		System.out.println("\n-- Intentar eliminar album inexistente (id=999) --");
		servicioAlbum.eliminar(999L);
		System.out.println("El programa continúa correctamente.");

		// Cerrar la sesión al finalizar
		ConnectionUtil.shutdown();
		System.out.println("\n========== FIN ==========");
	}
}
