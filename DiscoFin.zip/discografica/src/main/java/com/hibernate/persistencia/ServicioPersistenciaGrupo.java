package main.java.com.hibernate.persistencia;

import org.hibernate.Session;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Grupo;

public class ServicioPersistenciaGrupo {

	public void persistir(Grupo grupo) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		session.persist(grupo);
		session.getTransaction().commit();
		session.close();
		
	}
	
	public Grupo obtener(long id) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Grupo grupo = session.find(Grupo.class, id);
		session.close();
		return grupo;
	}
	
	
	public void actualizar(Grupo grupo) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.merge(grupo);
		session.getTransaction().commit();
		session.close();
	}
	
	public void eliminar(long idGrupo) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.remove(session.find(Grupo.class, idGrupo));
		session.getTransaction().commit();
		session.close();
	}
}
