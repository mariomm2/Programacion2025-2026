package main.java.com.hibernate.persistencia;

import org.hibernate.Session;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Album;
import main.java.model.Grupo;

public class ServicioPersistenciaAlbum {

	public void persistir(Album album) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		
		session.persist(album);
		session.getTransaction().commit();
		session.close();
		
	}
	
	public Album obtener(long id) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Album album = session.find(Album.class, id);
		session.close();
		return album;
	}
	
	
	public void actualizar(Album album) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.merge(album);
		session.getTransaction().commit();
		session.close();
	}
	
	public void eliminar(long idAlbum) {
		Session session = ConnectionUtil.getSessionFactory().openSession();
		session.beginTransaction();
		session.remove(session.find(Album.class, idAlbum));
		session.getTransaction().commit();
		session.close();
	}
}
