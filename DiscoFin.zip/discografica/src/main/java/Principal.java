package main.java;

import java.time.LocalDate;

import main.java.com.hibernate.persistencia.ServicioPersistenciaAlbum;
import main.java.com.hibernate.persistencia.ServicioPersistenciaCancion;
import main.java.com.hibernate.persistencia.ServicioPersistenciaGrupo;
import main.java.model.Album;
import main.java.model.Cancion;
import main.java.model.Grupo;

public class Principal {

	public static void main(String[] args) {

		/*
		ServicioPersistenciaGrupo servicioPersistencia = new ServicioPersistenciaGrupo();
		servicioPersistencia.persistir(new Grupo("System of a Down", LocalDate.of(1994, 11, 10), null));
		System.out.println(servicioPersistencia.obtener(1L));		
		*/
		
		//CREAR / PERSISTIR CANCION
		ServicioPersistenciaCancion servicioPersistenciaCancion= new ServicioPersistenciaCancion();
		Cancion cancion1= new Cancion("Yonaguni","Cancion Yonaguni",4,".flac");
		Cancion cancion2= new Cancion("Diles","Cancion Diles",6,".flac");
		Cancion cancion3= new Cancion("VOY A LLEVARTE PA PR","Cancion de PR",3,".flac");
		Cancion cancion4= new Cancion("DTMF","Cancion de Debí Tirar Más Fotos",5,".flac");
		Cancion cancion5= new Cancion("Chambea","Cancion de Chambea",4,".flac");

		/*
		servicioPersistenciaCancion.persistir(cancion1);
		servicioPersistenciaCancion.persistir(cancion2);
		servicioPersistenciaCancion.persistir(cancion3);
		servicioPersistenciaCancion.persistir(cancion4);
		servicioPersistenciaCancion.persistir(cancion5);
		*/
		
		//OBTENER
	   //System.out.println(servicioPersistenciaCancion.obtener(1));
		
		//ACTUALIZAR
		//Cancion cancionAactualizar=servicioPersistenciaCancion.obtener(1);
		//CancionAactualizar.setDuracion(5);
		//servicioPersistenciaCancion.actualizar(cancionAactualizar);
		
		//BORRAR
		//servicioPersistenciaCancion.eliminar(2);
		
		
		//CREAR / PERSISTIR ALBUM
		ServicioPersistenciaGrupo servicioPersistenciaGrupo = new ServicioPersistenciaGrupo();
		ServicioPersistenciaAlbum servicioPersistenciaAlbum = new ServicioPersistenciaAlbum();

		/*
		Grupo grupo= new Grupo("Grupo Frontera",LocalDate.of(2022, 3, 1),null);
		
		servicioPersistenciaGrupo.persistir(grupo);
		
		Album album= new Album(2025,"DeBí TiRAR MáS FoToS",grupo);
		album.addCanciones(cancion1);
		album.addCanciones(cancion3);
		album.addCanciones(cancion4);
		
		servicioPersistenciaAlbum.persistir(album);
		
				
		//ACTUALIZAR ALBUM
		
		Album albumAactualizar=servicioPersistenciaAlbum.obtener(52);

		albumAactualizar.setYear(2026); //ANTES ERA 2025
		servicioPersistenciaAlbum.actualizar(albumAactualizar);
		
		*/
		
		
		//CREE OTRO ALBUM 
		
		/*
		Grupo grupo1= new Grupo("Bad Bunny and friends",LocalDate.of(2023, 3, 1),null);
		servicioPersistenciaGrupo.persistir(grupo1);

		Cancion cancion12= new Cancion("La ultima","Cancion Ultima",4,".flac");
		
		
		Album album2 = new Album(2025,"YHLQMDLG,",grupo1);
		
		album2.addCanciones(cancion12);
		
		servicioPersistenciaAlbum.persistir(album2);
		*/
		
		servicioPersistenciaAlbum.eliminar(102);
		
		
		
		
	}

}
