package com.hibernate.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "pedido")

public class Pedido {

	    @Id
	    @Column(name = "id_pedido")
	    @GeneratedValue(strategy = GenerationType.AUTO)
	    private long id;

	    @OneToMany(mappedBy = "pedido", cascade = CascadeType.MERGE)
	    private List<LineaPedido> lineas;

	    public Pedido() {
	    	super(); }

	    public long getId() {
	    	return id; }
	    
	    public List<LineaPedido> getLineas() {
	    	return lineas; }
	    
	    public void setLineas(List<LineaPedido> lineas) {
	    	this.lineas = lineas; }
	}

