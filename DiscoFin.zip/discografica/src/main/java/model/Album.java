package main.java.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "Album")
public class Album {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name="Año")
	private long year;
	
	@Column(name="Nombre")
	private String nombre;
	
	@ManyToOne
	@JoinColumn(name = "Grupo")
	private Grupo grupo;
	
	
	@OneToMany(mappedBy = "album", cascade = CascadeType.ALL)
	private List<Cancion> canciones=new ArrayList<>();


	public Album() {
		super();
	}


	public Album(long year, String nombre, Grupo grupo) {
		super();
		this.year = year;
		this.nombre = nombre;
		this.grupo = grupo;
	}

	
	public void addCanciones(Cancion cancion) {
		this.canciones.add(cancion);
		cancion.setAlbum(this);
		
	}


	public long getYear() {
		return year;
	}


	public void setYear(long year) {
		this.year = year;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public Grupo getGrupo() {
		return grupo;
	}


	public void setGrupo(Grupo grupo) {
		this.grupo = grupo;
	}


	public List<Cancion> getCanciones() {
		return canciones;
	}


	public void setCanciones(List<Cancion> canciones) {
		this.canciones = canciones;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}
	
	
}
