package main.java.com.hibernate.persistencia;

import org.hibernate.Session;

import main.java.com.hibernate.ConnectionUtil;
import main.java.model.Grupo;

public class ServicioPersistenciaGrupo {

	public void persistir(Grupo grupo) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			session.persist(grupo);
			session.getTransaction().commit();
			session.close();
			System.out.println("Grupo guardado: " + grupo);
		} catch (Exception e) {
			// Capturamos el error (ej: nombre duplicado) e informamos sin detener la app
			System.out.println("[ERROR] No se pudo guardar el grupo: " + e.getMessage());
		}
	}

	public Grupo obtener(long id) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			Grupo grupo = session.find(Grupo.class, id);
			session.close();
			if (grupo == null) {
				System.out.println("[ERROR] No existe ningún grupo con id=" + id);
			}
			return grupo;
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo obtener el grupo con id=" + id + ": " + e.getMessage());
			return null;
		}
	}

	public void actualizar(Grupo grupo) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			session.merge(grupo);
			session.getTransaction().commit();
			session.close();
			System.out.println("Grupo actualizado: " + grupo);
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo actualizar el grupo: " + e.getMessage());
		}
	}

	public void eliminar(long idGrupo) {
		try {
			Session session = ConnectionUtil.getSessionFactory().openSession();
			session.beginTransaction();
			Grupo grupo = session.find(Grupo.class, idGrupo);
			if (grupo == null) {
				System.out.println("[ERROR] No existe ningún grupo con id=" + idGrupo);
				session.close();
				return;
			}
			session.remove(grupo);
			session.getTransaction().commit();
			session.close();
			System.out.println("Grupo eliminado con id=" + idGrupo);
		} catch (Exception e) {
			System.out.println("[ERROR] No se pudo eliminar el grupo con id=" + idGrupo + ": " + e.getMessage());
		}
	}
}
