package com.hibernate;

import com.hibernate.model.LineaPedido;
import com.hibernate.model.Pedido;
import com.hibernate.model.Producto;
import org.hibernate.Session;
import java.time.LocalDate;

public class Principal {
    public static void main(String[] args) {

        // Crear
        //Session session = ConnectionUtil.getSessionFactory().openSession();
        //session.beginTransaction();

        //Producto producto = new Producto("Teclado", "Teclado de ordenador", LocalDate.now(), LocalDate.now());
        //session.persist(producto);

        //session.getTransaction().commit();
        //session.close();
        //System.out.println("Producto creado!");

        //ConnectionUtil.shutdown();
    	
    	//Leer
    	//Session session = ConnectionUtil.getSessionFactory().openSession();
    	//session.beginTransaction();

    	//Producto producto = session.find(Producto.class, 1L);
    	//System.out.println("Nombre: " + producto.getNombre());
    	//System.out.println("Descripcion: " + producto.getDescripcion());

    	//session.close();
    	
    	// Actualizar
    	//Session session = ConnectionUtil.getSessionFactory().openSession();
    	//session.beginTransaction();

    	//Producto producto = session.find(Producto.class, 1L);
    	//producto.setDescripcion("Nuevo producto");

    	//session.merge(producto);
    	//session.getTransaction().commit();
    	//session.close();
    	//System.out.println("Producto actualizado!");

    	// Eliminar
    	//Session session = ConnectionUtil.getSessionFactory().openSession();
    	//session.beginTransaction();

    	//session.remove(session.find(Producto.class, 1L));
    	//session.getTransaction().commit();
    	//session.close();
    	//System.out.println("Producto eliminado!");

    	//ConnectionUtil.shutdown();}
    	
    	// Primero necesitamos un producto existente (o crear uno nuevo)
    	ServicioPersistencia<Producto> servicioProducto = new ServicioPersistencia<>();
    	Producto producto1 = new Producto("Teclado", "Teclado de ordenador", LocalDate.now(), LocalDate.now());
    	Producto producto2 = new Producto("Raton", "Raton inalambrico", LocalDate.now(), LocalDate.now());
    	servicioProducto.persistirObjeto(producto1);
    	servicioProducto.persistirObjeto(producto2);

    	// Creamos y persistimos el pedido
    	ServicioPersistencia<Pedido> servicioPedido = new ServicioPersistencia<>();
    	Pedido pedido = new Pedido();
    	servicioPedido.persistirObjeto(pedido);

    	// Creamos y persistimos las líneas de pedido
    	LineaPedido lp1 = new LineaPedido(producto1, 3, "LP135-7A", pedido);
    	LineaPedido lp2 = new LineaPedido(producto2, 1, "LP135-7B", pedido);

    	ServicioPersistencia<LineaPedido> servicioLinea = new ServicioPersistencia<>();
    	servicioLinea.persistirObjeto(lp1);
    	servicioLinea.persistirObjeto(lp2);

    	System.out.println("Pedido y líneas creados!");
    	ConnectionUtil.shutdown();
    }}